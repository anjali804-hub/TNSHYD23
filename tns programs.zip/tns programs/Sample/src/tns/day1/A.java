package tns.day1;

public class A {
	private void display()
	{
		System.out.println("hello");// TODO Auto-generated method stub
	}

	public static void main(String[] args) {
		A a1=new A();
		a1.display();
	

	}

}
