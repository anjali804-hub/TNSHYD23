package tns.day1;

 class C {

    void method()
	{
		System.out.println("hello everyone");
	}

}
public class Defualt
{
public static void main(String[] args)
{
	C d =new C();
    d.method();
}
}