package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Employee;
import com.example.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired 
	private EmployeeService service;

	@PostMapping("/employee")
	public Employee saveEmployee(@RequestBody Employee employee) {
    	
    	return service.saveEmployee(employee);
		
	}
	 @GetMapping("/employee")
	    public List<Employee> fetchEmployeeList() {
	        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
	        return service.fetchEmployeeList();
	    }
	
	 
	 
	 @GetMapping("/employee/{id}")
	    public Employee fetchEmployeetById(@PathVariable("id") Long id)
	            {
	        return service.fetchEmployeeById(id);
	    }
	 
	 
	  @DeleteMapping("/employee/{id}")
	    public String deleteEmployeeById(@PathVariable("id") Long id) {
		  service.deleteEmployeeById(id);
	        return "Employee deleted Successfully!!";
	    }
	  @PutMapping("/employee/{id}")
	  public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails) {
	      Employee existingEmployee = service.fetchEmployeeById(id);
	      
	      // Update the fields of the existing employee with the new values
	      existingEmployee.setName(employeeDetails.getName());
	      existingEmployee.setDob(employeeDetails.getDob());
	      existingEmployee.setSalary(employeeDetails.getSalary());
	      existingEmployee.setAddress(employeeDetails.getAddress());
	      existingEmployee.setDesignation(employeeDetails.getDesignation());
	      existingEmployee.setShop(employeeDetails.getShop());
	      
	      // Save the updated employee
	      return service.saveEmployee(existingEmployee);
	  }

	 
	

}
