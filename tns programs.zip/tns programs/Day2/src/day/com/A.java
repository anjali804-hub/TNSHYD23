package day.com;

public class A {
	int a=20;
	static int b=30;
	int Display()
	{
		return 0;
	}
	public void Display1()
	{
		System.out.println("hello");
	}
	Public static void main(String args[])
	{
		int c=30;
		System.out.println(c);
		A a1=new A();
		System.out.println(a1.a);
		System.out.println(a1.Display());
		System.out.println(A.b);
		System.out.println(A.Display());
		}
}
