package tns.day1;

public class Protected1 extends Protected {

	public static void main(String[] args) {
		Protected1 p=new Protected1();
		p.main();
		System.out.println(p.a);
		System.out.println(p.b);
		// TODO Auto-generated method stub

	}

}
