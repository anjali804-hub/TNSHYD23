package day2.com;

public class A {
	int a=20;
	static int b=30;
	int method()
	{
		return 0;
	}
	public void method2()
	{
		System.out.println("hello");
	}
}
